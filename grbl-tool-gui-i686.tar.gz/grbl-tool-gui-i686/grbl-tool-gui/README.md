grbl-tool-gui
=============

Graphical User Interface for grbl, using node-webkit.

This project use node-webkit, documentation on how to install it here : https://github.com/rogerwang/node-webkit 

You have to install ``serialport`` module for your version of node-webkit in order to run grbl-tool-gui properly, following those intructions : https://github.com/rogerwang/node-webkit/wiki/Build-native-modules-with-nw-gyp

